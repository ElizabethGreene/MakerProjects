Topsy tail tool by VE2YTQ on Thingiverse: https://www.thingiverse.com/thing:2685398

Summary:
The original thing's STL file is broken, so I took 5 minutes to model my own version.Nothing fancy, but it works fine.Enjoy!