Happy Birthday cake topper by bryan7 on Thingiverse: https://www.thingiverse.com/thing:3058861

Summary:
Happy Birthday cake topper 