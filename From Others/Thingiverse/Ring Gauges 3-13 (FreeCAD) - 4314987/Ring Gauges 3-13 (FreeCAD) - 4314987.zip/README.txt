Ring Gauges 3-13 (FreeCAD) by LinuxGuy2020 on Thingiverse: https://www.thingiverse.com/thing:4314987

Summary:
This is a set of jewelry ring gauges sizes 3-13 (14.0mm-22.2mm). A pair of calipers is recommended to ream and check each one to fine tune. I got mine within .010in which is accurate enough for manufacturing tolerances. I personally used para-cord to keep them all together. The specs were taken from a jeweler website and are as follows:03 - 14.00mm04 - 14.80mm05 - 15.60mm06 - 16.45mm07 - 17.30mm08 - 18.20mm09 - 19.00mm10 - 19.80mm11 - 20.60mm12 - 21.40mm13 - 22.20mm
