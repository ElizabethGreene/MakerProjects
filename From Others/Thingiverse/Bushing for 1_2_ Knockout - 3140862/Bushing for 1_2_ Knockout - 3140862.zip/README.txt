Bushing for 1/2" Knockout by reactron on Thingiverse: https://www.thingiverse.com/thing:3140862

Summary:
Threaded, printable bushing for electrical boxes with 1/2" knockouts (roughly 20mm opening). 
